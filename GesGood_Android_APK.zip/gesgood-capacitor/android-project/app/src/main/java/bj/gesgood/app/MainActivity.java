package bj.gesgood.app;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        // Splash screen
        registerPlugin(com.getcapacitor.plugin.WebViewPlugin.class);
        super.onCreate(savedInstanceState);
    }
}
