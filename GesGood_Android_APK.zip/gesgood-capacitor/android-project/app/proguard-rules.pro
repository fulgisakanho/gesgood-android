# GesGood — Règles ProGuard
-keep class bj.gesgood.app.** { *; }
-keep class com.getcapacitor.** { *; }
-keepattributes *Annotation*
-keepattributes SourceFile,LineNumberTable
